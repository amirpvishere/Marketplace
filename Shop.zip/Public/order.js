function cancelOrder(orderId) {
    fetch(`/api/orders/cancel/${orderId}`, { method: "POST" })
    .then(response => {
        if (response.ok) {
            window.location.reload();  // ✅ Automatically refreshes page after cancellation
        } else {
            alert("Error cancelling order.");
        }
    });
}