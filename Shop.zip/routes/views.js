const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const Cart = require('../models/Cart');
const Order = require('../models/Order');
const axios = require('axios');


const EXTERNAL_API_URL = process.env.EXTERNAL_API_URL;

router.get('/', async (req, res) => {
    try {
        // Internal DB products
        let dbProducts = await Product.find();

        // External API fetch
        let externalProducts = [];
        try {
            const response = await axios.get('http://localhost:5000/api/products');
            externalProducts = response.data.map(p => ({
                ...p,
                source: 'external'
            }));
        } catch (err) {
            console.error('Failed to fetch external products:', err.message);
        }

        const allProducts = [...dbProducts, ...externalProducts];

        // Sort for display
        allProducts.sort((a, b) => (b.inStock > 0) - (a.inStock > 0));

        res.render('index', { products: allProducts, session: req.session || {} });

    } catch (err) {
        console.error('Error rendering home:', err);
        res.status(500).send('Error loading homepage');
    }
});

router.get('/cart/:userId', async (req, res) => {
    try {
        const cart = await Cart.findOne({ userId: req.params.userId }).populate('items.product');
        res.render('cart', { cart });
    } catch (error) {
        res.status(500).send("Error loading cart");
    }
});

router.get('/orders/:userId', async (req, res) => {
    try {
        const orders = await Order.find({ userId: req.params.userId }).populate('items.product').sort({ createdAt: -1 });
        res.render('orders', { orders });
    } catch (error) {
        res.status(500).send("Error loading orders");
    }
});

module.exports = router;
