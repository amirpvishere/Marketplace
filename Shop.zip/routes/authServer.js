const express = require('express');
const router = express.Router();
const Client = require('../models/Client');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');


const JWT_SECRET = process.env.JWT_SECRET || 'mysecret';
const REFRESH_SECRET = 'your_refresh_secret';

// Issue token
router.post('/oauth/token', async (req, res) => {
  const { grant_type, client_id, client_secret } = req.body;

  if (grant_type !== 'client_credentials') {
    return res.status(400).json({ error: 'Unsupported grant_type' });
  }

  try {
    const client = await Client.findOne({ clientId: client_id });
    if (!client) return res.status(401).json({ error: 'Invalid client ID' });

    const isMatch = await bcrypt.compare(client_secret, client.clientSecret);
    if (!isMatch) return res.status(401).json({ error: 'Invalid client secret' });

    const payload = {
      clientId: client.clientId,
      scopes: client.scopes
    };

    const accessToken = jwt.sign(payload, JWT_SECRET, { expiresIn: '15m' });
    const refreshToken = jwt.sign(payload, REFRESH_SECRET, { expiresIn: '7d' });

    return res.json({ access_token: accessToken, refresh_token: refreshToken });

  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Internal server error' });
  }
});


  

module.exports = router;
