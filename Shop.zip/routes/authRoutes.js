const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

const JWT_SECRET = process.env.JWT_SECRET;


router.get('/login', (req, res) => {
    res.render('login');
});

router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        const user = await User.findOne({ username });
        if (user && await bcrypt.compare(password, user.password)) {
            // GENERATE JWT TOKEN
            const token = jwt.sign({ userId: user._id, username: user.username }, JWT_SECRET, { expiresIn: '1h' });

            req.session.userId = user._id;

            req.session.username = user.username;
            req.session.isAdmin = user.isAdmin;
            res.redirect('/');
            
        } else {
            res.status(401).json({ message: "Invalid credentials" });
        }
    } catch (error) {
        console.error("Login Error:", error);
        res.status(500).json({ message: "Internal Server Error" });
    }
});


router.get('/register', (req, res) => {
    res.render('register', { errorMessage: null });
});

// REGISTER POST
router.post('/register', async (req, res) => {
    try {
        const { username, email, password, age, country, phone } = req.body;

        if (!username || !password || !phone) {
            return res.status(400).send("Username, password, and phone are required.");
        }

        const existingUser = await User.findOne({ username });
        if (existingUser) {
            return res.status(409).send("User Already Exist.");
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const newUser = new User({
            username,
            email: email || "",
            password: hashedPassword,
            age,
            country,
            phone,
            role: req.body.role || 'user'
        });

        await newUser.save();

        // ✅ Log the user in automatically
        req.session.userId = newUser._id;
        req.session.username = newUser.username;
        req.session.isAdmin = newUser.role === 'admin';

        return res.redirect('/');
    } catch (error) {
        console.error('Registration error: ', error);
        res.status(500).send('Internal Server Error');
    }
});

function authenticateToken(req, res, next) {
    const token = req.header('Authorization')?.split(' ')[1]; 
    if (!token) return res.status(401).json({ message: "Access denied" });

    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.status(403).json({ message: "Invalid token" });
        req.user = user;
        next();
    });
}

module.exports = { router, authenticateToken };
