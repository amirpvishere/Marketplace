const express = require('express');
const router = express.Router();
const Client = require('../models/Client');
const uuid = require('uuid'); 
const bcrypt = require('bcryptjs');

const validScopes = ['read:products', 'write:products', 'read:orders', 'admin'];


router.get('/', async (req, res) => {
  try {
    const apps = await Client.find();
    res.render('admin', { apps });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
});


router.post('/', async (req, res) => {
  try {
    const { name, scopes } = req.body;

    const clientId = uuid.v4();
    const rawSecret = uuid.v4();
    const hashedSecret = await bcrypt.hash(rawSecret, 10);

   
    const scopesArray = Array.isArray(scopes)
      ? scopes
      : scopes.split(',').map(s => s.trim());

    const newClient = new Client({
      name,
      clientId,
      clientSecret: hashedSecret,
      scopes: scopesArray
    });

    await newClient.save();

    const apps = await Client.find();
    res.render('admin-success', { 
      clientId,
      clientSecret: rawSecret,
     });

  } catch (error) {
    console.error('Error creating client:', error);
    res.status(500).send('Internal Server Error');
  }
});


router.post('/delete/:id', async (req, res) => {
  try {
    await Client.deleteOne({ client_id: req.params.clientId }); 
    res.redirect('/admin');
  } catch (error) {
    console.error('Failed to delete client:', error);
    res.status(500).send("Error deleting client.");
  }
});

module.exports = router;
