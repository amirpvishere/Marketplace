require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const productRoutes = require('./routes/productRoutes');
const Product = require("./models/Product")


const app = express();
app.use(express.json());
app.use(cors());


MONGODB_USERNAME = process.env.MONGODB_USERNAME
MONGODB_PASSWORD = process.env.MONGODB_PASSWORD
const mongoURI = `mongodb+srv://${MONGODB_USERNAME}:${MONGODB_PASSWORD}@cluster0.p2q2e.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0`;
mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log('MongoDB connected successfully!');
    })
    .catch(err => {
        console.error('MongoDB connection error:', err);
});


async function fetchWalmartProducts(query) {
    try {
        const response = await axios.get(`https://api.walmart.com/some-endpoint`, {
            headers: { 'Authorization': `Bearer ${process.env.WALMART_API_KEY}` }
        });
        return response.data.items.map(item => ({
            name: item.name,
            price: item.salePrice,
            retailer: "Walmart Canada",
            link: item.productUrl
        }));
    } catch (error) {
        console.error("Error fetching Walmart products:", error.message);
        return [];
    }
}


async function fetchTargetProducts(query) {
    try {
        const response = await axios.get(`https://api.target.com/some-endpoint`, {
            headers: { 'Authorization': `Bearer ${process.env.TARGET_API_KEY}` }
        });
        return response.data.items.map(item => ({
            name: item.title,
            price: item.price.current,
            retailer: "Target US",
            link: item.url
        }));
    } catch (error) {
        console.error("Error fetching Target products:", error.message);
        return [];
    }
}


app.get('/products', async (req, res) => {
    const query = req.query.q || "laptop";
    const walmartData = await fetchWalmartProducts(query);
    const targetData = await fetchTargetProducts(query);

    const products = [...walmartData, ...targetData];

    await Product.insertMany(products, { ordered: false }).catch(err => console.log(err));

    res.json(products);
});


app.use('/api', productRoutes);


const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));